
import CoreData

struct DataCore {
    
    private let Model: NSManagedObjectModel
    internal let coordinator: NSPersistentStoreCoordinator
    private let Url: URL
    internal let database: URL
    internal let persisting: NSManagedObjectContext
    internal let background: NSManagedObjectContext
    let context: NSManagedObjectContext
    
    
    
    static func shared() -> DataCore {
        struct share {
            
            static var shared = DataCore(modelName: "locations")!
        }
        return share.shared
    }
    
    
    
    init?(modelName: String) {
        
        guard let modelURL = Bundle.main.url(forResource: modelName, withExtension: "momd") else {
        
            return nil
        }
        
        self.Url = modelURL
        
        
        guard let model = NSManagedObjectModel(contentsOf: modelURL) else {
            return nil
        }
        
        self.Model = model
        
        
        coordinator = NSPersistentStoreCoordinator(managedObjectModel: model)
        
        persisting = NSManagedObjectContext(concurrencyType: .privateQueueConcurrencyType)
        persisting.persistentStoreCoordinator = coordinator
        
        
        context = NSManagedObjectContext(concurrencyType: .mainQueueConcurrencyType)
        context.parent = persisting
        
        
        background = NSManagedObjectContext(concurrencyType: .privateQueueConcurrencyType)
        background.parent = context
        
        
        let manager = FileManager.default
        
        guard let docUrl = manager.urls(for: .documentDirectory, in: .userDomainMask).first else {
            print("Unable reach the folder")
            return nil
        }
        
        self.database = docUrl.appendingPathComponent("model.sqlite")
        
       
        let options = [
            NSInferMappingModelAutomaticallyOption: true,
            NSMigratePersistentStoresAutomaticallyOption: true
        ]
        
        do {
            try addStoreCoordinator(NSSQLiteStoreType, configuration: nil, storeURL: database, options: options as [NSObject : AnyObject]?)
        } catch {
            print("unable add at \(database)")
        }
    }
    
    
    
    func addStoreCoordinator(_ storeType: String, configuration: String?, storeURL: URL, options : [NSObject:AnyObject]?) throws {
        
        try coordinator.addPersistentStore(ofType: NSSQLiteStoreType, configurationName: nil, at: database, options: nil)
        
    }
    
    
    func fetchPhotos(_ predicate: NSPredicate? = nil, entityName: String, sorting: NSSortDescriptor? = nil) throws -> [MyPhoto]? {
        let fetched = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        fetched.predicate = predicate
        if let sorting = sorting {
            fetched.sortDescriptors = [sorting]
        }
        guard let photo = try context.fetch(fetched) as? [MyPhoto] else {
            return nil
        }
        return photo
    }
    
    
    
    func fetchPin(_ predicate: NSPredicate, entityName: String, sorting: NSSortDescriptor? = nil) throws -> MyPin? {
        let fetched = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        fetched.predicate = predicate
        if let sorting = sorting {
            fetched.sortDescriptors = [sorting]
        }
        guard let pin = (try context.fetch(fetched) as! [MyPin]).first else {
            return nil
        }
        return pin
    }
    
    
    func fetchAllPins(_ predicate: NSPredicate? = nil, entityName: String, sorting: NSSortDescriptor? = nil) throws -> [MyPin]? {
        let fetched = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        fetched.predicate = predicate
        if let sorting = sorting {
            fetched.sortDescriptors = [sorting]
        }
        guard let pin = try context.fetch(fetched) as? [MyPin] else {
            return nil
        }
        return pin
    }
    
}





internal extension DataCore  {
    
    func dropAllData() throws {
        
        
        try coordinator.destroyPersistentStore(at: database, ofType:NSSQLiteStoreType , options: nil)
        try addStoreCoordinator(NSSQLiteStoreType, configuration: nil, storeURL: database, options: nil)
    }
}



extension DataCore {
    
    
    func autoSave(_ delayInSeconds : Int) {
        
        if delayInSeconds > 0 {
            do {
                try saveContext()
            } catch {
                print("Error autosaving")
            }
            
            let delayInNanoSeconds = UInt64(delayInSeconds) * NSEC_PER_SEC
            let time = DispatchTime.now() + Double(Int64(delayInNanoSeconds)) / Double(NSEC_PER_SEC)
            
            DispatchQueue.main.asyncAfter(deadline: time) {
                self.autoSave(delayInSeconds)
            }
        }
    }
    
    func saveContext() throws {
        context.performAndWait() {
            
            if self.context.hasChanges {
                do {
                    try self.context.save()
                } catch {
                    print("Error saving: \(error)")
                }
                
                self.persisting.perform() {
                    do {
                        try self.persisting.save()
                    } catch {
                        print("Error saving: \(error)")
                    }
                }
            }
        }
    }
    
}
