

import UIKit
import Kingfisher

class PhotoCell: UICollectionViewCell {
    
    static let identifier = "PhotoViewCell"
    
    var url_Photo: String = ""
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    

    func getImage(images: MyPhoto!){
               if let url = URL(string: images.imageUrl!){
               imageView.kf.indicatorType = .activity
               imageView.kf.setImage(with: url,options: [.transition(.fade(0.5))])
//                images.image = imageView.image? nil
               }
           }
}

extension UIViewController {

    var appDelegate: AppDelegate {
        return UIApplication.shared.delegate as! AppDelegate
    }

    func performUpdates(_ updates: @escaping () -> Void) {
        DispatchQueue.main.async {
            updates()
        } }


    func save() {
        do {
            try DataCore.shared().saveContext()
        } catch {
            showInfo(withTitle: "Error", withMessage: "Error saving: \(error)")
        }
    }


    func showInfo(withTitle: String = "Info", withMessage: String, action: (() -> Void)? = nil) {
        performUpdates {
            let ac = UIAlertController(title: withTitle, message: withMessage, preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .default, handler: {(alertAction) in
                action?()
            }))
            self.present(ac, animated: true)
        }
    }



}
