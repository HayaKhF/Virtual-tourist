

import UIKit
import Alamofire
class Client {
   
    var Mysession = URLSession.shared
    private var Mytasks: [String: URLSessionDataTask] = [:]
    
 
    
    class func shared() -> Client {
        struct Single {
            static var shared = Client()
        }
        return Single.shared
    }
    
    
    func search(latitude: Double, longitude: Double, totalPages: Int?, completion: @escaping (_ result: PhotosParser?, _ error: Error?) -> Void) {
        
        var page: Int {
            if let totalPages = totalPages {
                let page = min(totalPages, 4000/FlickerParameterValues_Client.PhotosPerPage)
                return Int(arc4random_uniform(UInt32(page)) + 1)
            }
            return 1
        }
        let boxx = minAndMaxBox(latitude: latitude, longitude: longitude)
        
        let parameter = [
            FlickerParameter_Flicker_Client.Method           : FlickerParameterValues_Client.SearchMethod
            , FlickerParameter_Flicker_Client.APIKey         : FlickerParameterValues_Client.APIKey
            , FlickerParameter_Flicker_Client.Format         : FlickerParameterValues_Client.ResponseFormat
            , FlickerParameter_Flicker_Client.Extras         : FlickerParameterValues_Client.MediumURL
            , FlickerParameter_Flicker_Client.NoJSONCallback : FlickerParameterValues_Client.DisableJSONCallback
            , FlickerParameter_Flicker_Client.SafeSearch     : FlickerParameterValues_Client.UseSafeSearch
            , FlickerParameter_Flicker_Client.BoundingBox    : boxx
            , FlickerParameter_Flicker_Client.PhotosPerPage  : "\(FlickerParameterValues_Client.PhotosPerPage)"
            , FlickerParameter_Flicker_Client.Page           : "\(page)"
        ]
        
        _ = getMethod(parameters: parameter) { (data, error) in
            if let error = error {
                completion(nil, error)
                return
            }
            guard let data = data else {
                let userInfo = [NSLocalizedDescriptionKey : "Not retrieve data."]
                completion(nil, NSError(domain: "taskForGETMethod", code: 1, userInfo: userInfo))
                return
            }
            
            do {
                let photosParser = try JSONDecoder().decode(PhotosParser.self, from: data)
                completion(photosParser, nil)
            } catch {
                print("\(#function) error: \(error)")
                completion(nil, error)
            }
        }
    }
    
    
    func cancelLoading(_ imageUrl: String) {
        Mytasks[imageUrl]?.cancel()
        Mytasks.removeValue(forKey: imageUrl)
    }
    
    func loadingImage(imageUrl: String, result: @escaping (_ result: Data?, _ error: NSError?) -> Void) {
        guard let url = URL(string: imageUrl) else {
            return
        }
        let task = getMethod(nil, url, parameters: [:]) { (data, error) in
            result(data, error)
            self.Mytasks.removeValue(forKey: imageUrl)
        }
        
        if Mytasks[imageUrl] == nil {
           Mytasks[imageUrl] = task
        }
    }
    
    
    
}





extension Client {
    
    struct Flicker_Client {
        static let API = "https"
        static let Host = "api.flickr.com"
        static let Path = "/services/rest"
        static let BoxHalfWidth = 0.2
        static let BoxHalfHeight = 0.2
        static let LatRange = (-90.0, 90.0)
        static let LonRange = (-180.0, 180.0)
    }
    
    
    struct FlickerParameter_Flicker_Client {
        static let Method = "method"
        static let APIKey = "api_key"
        static let GalleryID = "gallery_id"
        static let Extras = "extras"
        static let Format = "format"
        static let NoJSONCallback = "nojsoncallback"
        static let SafeSearch = "safe_search"
        static let BoundingBox = "bbox"
        static let PhotosPerPage = "per_page"
        static let Accuracy = "accuracy"
        static let Page = "page"
    }
    

    
    struct FlickerParameterValues_Client {
        static let SearchMethod = "flickr.photos.search"
        static let APIKey = "39775f20961d59de973dbf6cb9681f64"
        static let ResponseFormat = "json"
        static let DisableJSONCallback = "1"
        static let MediumURL = "url_n"
        static let UseSafeSearch = "1"
        static let PhotosPerPage = 30
        static let AccuracyCityLevel = "11"
        static let AccuracyStreetLevel = "16"
    }
}






extension Client {
    
    
    func getMethod(
        _ method               : String? = nil,
        _ customUrl            : URL? = nil,
        parameters             : [String: String],
        completionHandlerForGET: @escaping (_ result: Data?, _ error: NSError?) -> Void) -> URLSessionDataTask {
        
        
        let request: NSMutableURLRequest!
        if let customUrl = customUrl {
            request = NSMutableURLRequest(url: customUrl)
        } else {
            request = NSMutableURLRequest(url: URLBuild(parameters, withPathExtension: method))
        }
        
        showActivityIndicator(true)
        
        let task = Mysession.dataTask(with: request as URLRequest) { (data, response, error) in
            
            func errorSend(_ error: String) {
                self.showActivityIndicator(false)
                print(error)
                let userInfo = [NSLocalizedDescriptionKey : error]
                completionHandlerForGET(nil, NSError(domain: "taskForGETMethod", code: 1, userInfo: userInfo))
            }
            
            
            if let err = error {
                
                
                if (err as NSError).code == URLError.cancelled.rawValue {
                    completionHandlerForGET(nil, nil)
                } else {
                    errorSend("Error with your request: \(err.localizedDescription)")
                }
                return
            }
            
            
            guard let status = (response as? HTTPURLResponse)?.statusCode, status >= 200 && status <= 299 else {
                errorSend("Your request returned 2xx!")
                return
            }
            
            
            guard let data = data else {
                errorSend("No data returned!")
                return
            }
            
            self.showActivityIndicator(false)
            completionHandlerForGET(data, nil)
            
        }
        
        task.resume()
        
        return task
    }
    
    
    
    private func URLBuild(_ parameters: [String: String], withPathExtension: String? = nil) -> URL {
        
        var comps = URLComponents()
        comps.scheme = Flicker_Client.API
        comps.host = Flicker_Client.Host
        comps.path = Flicker_Client.Path + (withPathExtension ?? "")
        comps.queryItems = [URLQueryItem]()
        
        for (key, value) in parameters {
            let queryItem = URLQueryItem(name: key, value: value)
            comps.queryItems!.append(queryItem)
        }
        
        return comps.url!
    }
    
    
    private func minAndMaxBox(latitude: Double, longitude: Double) -> String {
        
        let minimumLonitude = max(longitude - Flicker_Client.BoxHalfWidth, Flicker_Client.LonRange.0)
        let minimumLatitude = max(latitude  - Flicker_Client.BoxHalfHeight, Flicker_Client.LatRange.0)
        let maximumLongitude = min(longitude + Flicker_Client.BoxHalfWidth, Flicker_Client.LonRange.1)
        let maximumLatitude = min(latitude  + Flicker_Client.BoxHalfHeight, Flicker_Client.LatRange.1)
        return "\(minimumLonitude),\(minimumLatitude),\(maximumLongitude),\(maximumLatitude)"
    }
    

    private func showActivityIndicator(_ show: Bool) {
        DispatchQueue.main.async {
            UIApplication.shared.isNetworkActivityIndicatorVisible = show
        }
    }
}
